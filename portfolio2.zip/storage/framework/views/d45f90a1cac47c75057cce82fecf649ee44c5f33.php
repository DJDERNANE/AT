<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('title'); ?>
        <?php echo e('cat'); ?>

    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('cats.add')); ?>">
        <button class='byn btn-success p-2 my-2 text-xl'>Ajouter +</button>
    </a>
    
        <table class="table table-striped-columns">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">category Name</th>
                    <th scope="col">Seting</th>
                </tr>
            </thead>
            <tbody>
            <?php if (! ($cats)): ?>
            <tr>
                <p>Les Categories n'existe pas encore ... </p>
            </tr>
            <?php else: ?>
            <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <th scope="row"><?php echo e($cat->id); ?></th>
                    <td class='text-xl'><?php echo e($cat->name); ?></td>
                    <td>
                        <a href="<?php echo e(route('cats.edit', $cat->id)); ?>">
                            <button type="button" class="btn btn-primary">Edit</button>
                        </a>
                        <form method="post" action="<?php echo e(route('cats.destroy', $cat->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <input type="submit" class="btn btn-danger" value="Delete">
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

            </tbody>
        </table>
    <?php $__env->stopSection(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\portfolio2\resources\views/categories.blade.php ENDPATH**/ ?>