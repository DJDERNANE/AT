
<?php $__env->startSection('styling'); ?>
<style>
    h1 {
        text-align: center;
        font-size: 40px;
    }

    .product-form {
        display: flex;
        flex-direction: column;
        background-color: #fff;
        border-radius: 5px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        padding: 20px;
        max-width: 600px;
        margin: 0 auto;
    }

    .form-group {
        display: flex;
        flex-direction: column;
        margin-bottom: 20px;
    }

    .form-group label {
        font-size: 18px;
        font-weight: bold;
        margin-bottom: 5px;
    }

    .form-group input[type="text"],
    .form-group textarea,
    .form-group input[type="number"],
    .form-group input[type="file"],
    select {
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 16px;
        margin-top: 5px;
    }

    .form-button {
        background-color: #007bff;
        color: #0069d9;
        border: #0069d9 solid 2px;
        border-radius: 5px;
        padding: 10px 20px;
        font-size: 18px;
        cursor: pointer;
        transition: all 0.5s ease;
        margin-top: 20px;
    }

    .form-button:hover {
        background-color: #0069d9;
        color: white
    }
</style>
<?php $__env->stopSection(); ?>


<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('title'); ?>
        <?php echo e('Edit Project'); ?>

    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('project.update',$project->id)); ?>" method="post" enctype="multipart/form-data" class="product-form">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <h1>EDIT PROJECT</h1>
        <div class="form-group">
            <label for="Project-name">Project name :</label>
            <input type="text" name="name_pro" id="Project-name" value="<?php echo e($project->project_name); ?>">
        </div>

        <div class="form-group">
            <label for="Project-description">English Description</label>
            <textarea name="desc_en" ><?php echo e($project->getTranslation('desc', 'en')); ?></textarea>
        </div>
        <div class="form-group">
            <label for="Project-description">Arabic Description</label>
            <textarea name="desc_ar" ><?php echo e($project->getTranslation('desc', 'ar')); ?></textarea>
        </div>
        <div class="form-group">
            <label for="Project-image"> Image :</label>
            <input type="file" name="img" id="Project-image" >
        </div>
        <div class="form-group">
            <label for="project-link"> Link :</label>
            <input type="text" name="link" id="project-link" value="<?php echo e($project->link); ?>">
        </div>
        <button type="submit" class="form-button btn btn-primary">Save</button>
    </form>
<?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\laravel\portfolio2\resources\views/editProject.blade.php ENDPATH**/ ?>