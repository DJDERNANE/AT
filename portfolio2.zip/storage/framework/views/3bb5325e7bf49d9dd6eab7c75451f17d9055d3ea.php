
<?php $__env->startSection('title'); ?>
        <?php echo e('service'); ?>

    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('services.add',$startup->token)); ?>">
        <button class='byn btn-success p-2 my-2 text-xl'>Ajouter +</button>
    </a>
    
        <table class="table table-striped-columns">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">service Name</th>
                    <th scope="col">picture</th>
                    <th scope="col">Seting</th>
                </tr>
            </thead>
            <tbody>
            <?php if (! ($services)): ?>
            <tr>
                <p>Les serviceegories n'existe pas encore ... </p>
            </tr>
            <?php else: ?>
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <th scope="row"><?php echo e($service->id); ?></th>
                    <td class='text-xl'><?php echo e($service->service_name); ?></td>
                    <td class='text-xl'><img style="width: 200px" src='http://localhost:8000/pictures/services/<?php echo e($service->picture); ?>'/></td>
                    <td>
                        <form method="post" action="<?php echo e(route('services.destroy',[$service->id,$startup->token])); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <input type="submit" class="btn btn-danger" value="Delete">
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

            </tbody>
        </table>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appstartup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio2\resources\views/startup/services.blade.php ENDPATH**/ ?>