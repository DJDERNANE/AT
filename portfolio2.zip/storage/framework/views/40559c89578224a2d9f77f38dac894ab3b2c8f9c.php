
    <?php $__env->startSection('title'); ?>
        <?php echo e($startup->startup); ?>

    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
    <a href="">
        <button class='byn btn-success p-2 my-2 text-xl'> Modifier</button>
    </a>
    
        <table class="table table-striped-columns">
            <thead>
                <tr>
                    <th scope="col">Nom </th>
                    <td scope="col"><?php echo e($startup->fullname); ?></td>
                </tr>
                <tr>
                    <th scope="col">Email </th>
                    <td scope="col"><?php echo e($startup->email); ?></td>
                </tr>
                <tr>
                    <th scope="col">Numero Telephone </th>
                    <td scope="col"><?php echo e($startup->phone); ?></td>
                </tr>
                <tr>
                    <th scope="col">Startup </th>
                    <td scope="col"><?php echo e($startup->startup); ?></td>
                </tr>
                <tr>
                    <th scope="col">Wilaya </th>
                    <td scope="col"><?php echo e($startup->wilaya); ?></td>
                </tr>
                <tr>
                    <th scope="col">Description </th>
                    <td scope="col"><?php echo e($startup->desc); ?></td>
                </tr>
                <tr>
                    <th scope="col">Label </th>
                    <td scope="col"><?php echo e($startup->label); ?></td>
                </tr>
                <tr>
                    <th scope="col">Date de Creation </th>
                    <td scope="col"><?php echo e($startup->creation_date); ?></td>
                </tr>
                <tr>
                    <th scope="col">Site Web </th>
                    <td scope="col"><?php echo e($startup->website); ?></td>
                </tr>
                <tr>
                    <th scope="col">Date de Creation </th>
                    <td scope="col"><?php echo e($startup->creation_date); ?></td>
                </tr>
                <tr>
                    <th scope="col">Social Media </th>
                    <td scope="col"><?php echo e($startup->socialmedia); ?></td>
                </tr>
            </thead>
          
        </table>
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.appstartup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio2\resources\views/startup/show.blade.php ENDPATH**/ ?>