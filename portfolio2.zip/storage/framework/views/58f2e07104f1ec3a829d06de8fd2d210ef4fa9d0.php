<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    
    <h1>
        Hey <?php echo e($data['name']); ?>

    </h1>
    <p>
        Thank your for your message we will replay to you in few minites
    </p>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\portfolio2\resources\views/mail/client.blade.php ENDPATH**/ ?>