<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>
        Message from <?php echo e($data['name']); ?>

    </h1>
    <h2>E-Mail : <?php echo e($data['email']); ?></h2>
    <h2>Phone : <?php echo e($data['phone']); ?></h2>
    <h2>Subject : <?php echo e($data['subject']); ?></h2>
    <p>
        <?php echo e($data['msg']); ?>

    </p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\portfolio2\resources\views/mail/adminMsg.blade.php ENDPATH**/ ?>