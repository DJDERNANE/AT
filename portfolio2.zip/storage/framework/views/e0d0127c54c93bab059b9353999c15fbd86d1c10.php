<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('title'); ?>
        <?php echo e('Message'); ?>

    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
     <h1>
        Subject : <?php echo e($message->subject); ?>

     </h1>
     <h1>
        From : <?php echo e($message->name); ?>

     </h1>
     <h3>Information : <?php echo e($message->email); ?> / <?php echo e($message->phone); ?></h3>
     <br><br>
     <h3>
        Message content :
     </h3>
     <p>
        <?php echo e($message->msg); ?>

     </p><br>
     <b>
        sended at <?php echo e($message->created_at); ?>

     </b>
    <?php $__env->stopSection(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\laravel\portfolio2\resources\views/ClientMessage.blade.php ENDPATH**/ ?>