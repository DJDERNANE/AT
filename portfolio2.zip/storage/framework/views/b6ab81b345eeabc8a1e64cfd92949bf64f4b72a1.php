<?php
use App\Models\comment;
use Illuminate\Http\Request;
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Transforming Visions into Digital Reality – Your Go-To Web Developer for Creating Stunning Websites and E-Commerce Platforms. If you're seeking to 'make my website' or establish a powerful e-commerce site, you've come to the right place. Explore my portfolio, showcasing a diverse range of projects where I've transformed client ideas into engaging online platforms. With a proven record of crafting user-friendly designs and seamless functionality, I'm dedicated to making your online dreams a reality. Elevate your digital presence today with a web developer who understands your unique needs.">
    <title>Dernane DJILALI</title>


    <!-------------------- Bootsrap Links --------------->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css"
        integrity="sha384-b6lVK+yci+bfDmaY1u0zE8YYJt0TZxLEAFyYSLHId4xoVvsrQu3INevFKo+Xir8e" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('fontawesome/css/all.min.css')); ?>">



    <!------------------- style links ------------------->
    <link rel="stylesheet" href="style/style.css">
    <link rel="stylesheet" href="style/responsice.css">
    <link rel="stylesheet" href="style/swiper.css">
    <?php if(app()->getLocale() == 'ar'): ?>
        <link rel="stylesheet" href="style/ar.css">
    <?php endif; ?>


    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">


</head>

<body>

    <div class="parent">
        <!-------------------- Left side --------------------->
        <div class="left_side" data-aos="fade-down" data-aos-duration="1000">
            <div class="header">
                <h3>
                    <?php echo e(trans('portfolio.name')); ?>

                </h3>
            </div>
            <div class="content">
                <img src="imgs/myimg2.jpeg" alt="">
                <div class="contact">
                    <p class="email">
                        derndjilali38@gmail.com
                    </p>
                    <p class="copyright">
                        <i class="bi bi-c-circle"></i> 2023,<?php echo e(trans('portfolio.right')); ?>

                    </p>
                    <p class="contactme">
                        <?php echo e(trans('portfolio.follow')); ?>

                    </p>
                    <div class="my-links">
                        <a href="https://www.instagram.com/djilalidernane/" target="_blank">
                            <i class="bi bi-instagram"></i>
                        </a>
                        <a href="https://github.com/DJDERNANE" target="_blank">
                            <i class="bi bi-github"></i>
                        </a>

                        <a href="">
                            <i class="bi bi-whatsapp"></i>
                        </a>

                        <a href="https://www.linkedin.com/in/djilali-dernane-8b1984218/" target="_blank">
                            <i class="bi bi-linkedin"></i>
                        </a>

                    </div>

                    <a href="MONCV.pdf" target="_blank">
                        <button>
                            <i class="bi bi-cloud-arrow-down-fill"></i> <?php echo e(trans('portfolio.cv')); ?>

                        </button>
                    </a>

                </div>
            </div>
        </div>

        <!---------------------- Right_side------------------------->
        <div class="right_side">
            <div class="header">
                <div class="navbtn" id="navbtn">
                    <span></span>
                    <span></span>
                </div>
            </div>
            <div class="navigation" id="navigation">
                <ul>
                    <li>
                        <a href="#home">
                            <i class="bi bi-house-door"></i>
                            <p><?php echo e(trans('portfolio.home')); ?></p>
                        </a>
                    </li>
                    <li>
                        <a href="#about">
                            <i class="bi bi-person"></i>
                            <p><?php echo e(trans('portfolio.about')); ?></p>
                        </a>
                    </li>
                    <li>
                        <a href="#skils">
                            <i class="bi bi-list-task"></i>
                            <p><?php echo e(trans('portfolio.skils')); ?></p>
                        </a>
                    </li>
                    <li>
                        <a href="#portfolio">
                            <i class="bi bi-pc-display-horizontal"></i>
                            <p><?php echo e(trans('portfolio.portfolio')); ?></p>
                        </a>
                    </li>


                    <li>
                        <a href="#contact">
                            <i class="bi bi-envelope"></i>
                            <p><?php echo e(trans('portfolio.contact')); ?></p>
                        </a>
                    </li>
                    <li class="dropdown">
                        <i class="bi bi-translate"></i>
                        <button id="lang" class="btn btn-secondary dropdown-toggle" type="button"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            <?php echo e(trans('portfolio.language')); ?>

                        </button>
                        <ul class="dropdown-menu" id="langmenu"
                            style="
                        margin-top: 40px;
                    ">
                            <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a rel="alternate" hreflang="<?php echo e($localeCode); ?>"
                                        href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>">
                                        <?php echo e($properties['native']); ?>

                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>

                </ul>
            </div>
            <div class="home" id="home" data-aos="zoom-in-down" data-aos-duration="1500">
                <div class="title" data-aos="fade-right" data-aos-duration="1800">
                    <i class="bi bi-house-door"></i> <?php echo e(trans('portfolio.home')); ?>

                </div>
                <h1>
                    <?php echo e(trans('portfolio.homeTitle1')); ?> <span><?php echo e(trans('portfolio.name')); ?></span> ,
                    <?php echo e(trans('portfolio.homeTitle2')); ?><span><?php echo e(trans('portfolio.homeTitle3')); ?></span>
                </h1>
                <p class="desc">
                    <?php echo e(trans('portfolio.homeDesc')); ?>

                </p>
            </div>

            <div class="pic-animation" data-aos="fade-down" data-aos-duration="1000">
                <img src="imgs/my-portfolio.png" alt="">
                <i class="bi bi-arrow-down"></i>
            </div>
            <div class="stats">
                <div data-aos="fade-right" data-aos-duration="800">
                    +4
                    <p>
                        <?php echo e(trans('portfolio.experience')); ?>

                    </p>

                </div>
                <div data-aos="fade-left" data-aos-duration="800">
                    +15
                    <p>
                        <?php echo e(trans('portfolio.project')); ?>

                    </p>
                </div>
            </div>


            <div class="about" id="about">
                <div class="title" data-aos="fade-right" data-aos-duration="800">
                    <i class="bi bi-person"></i> <?php echo e(trans('portfolio.about')); ?>

                </div>

                <h1 data-aos="fade-right" data-aos-duration="800">
                    <?php echo e(trans('portfolio.aboutTitle1')); ?> <br><span><?php echo e(trans('portfolio.aboutTitle2')); ?></span>
                </h1>

                <p data-aos="flip-down" data-aos-duration="800">
                    <?php echo e(trans('portfolio.aboutDesc1')); ?> <br>

                    <?php echo e(trans('portfolio.aboutDesc2')); ?> <br>

                    <?php echo e(trans('portfolio.aboutDesc3')); ?> <br>

                    <?php echo e(trans('portfolio.aboutDesc4')); ?>

                </p>
            </div>

            <div class="skils" id="skils">
                <div class="title" data-aos="fade-right" data-aos-duration="800">
                    <i class="bi bi-list-task"></i> <?php echo e(trans('portfolio.skils')); ?>

                </div>
                <h1 data-aos="fade-right">
                    <?php echo e(trans('portfolio.adv')); ?> <span><?php echo e(trans('portfolio.adv1')); ?></span>
                </h1>
                <div class="skils-content">
                    <div data-aos="fade-down-top" data-aos-duration="800">
                        <i class="fa-brands fa-html5"></i>
                        HTML
                    </div>
                    <div data-aos="fade-down-top" data-aos-duration="800">
                        <i class="fa-brands fa-css3-alt"></i>
                        CSS
                    </div>
                    <div data-aos="fade-down-top" data-aos-duration="800">
                        <i class="fa-brands fa-bootstrap"></i>
                        Bootstrap
                    </div>
                    <div data-aos="fade-up-top" data-aos-duration="800">
                        <i class="fa-brands fa-js"></i>
                        JS
                    </div>
                    <div data-aos="fade-up-top" data-aos-duration="800">
                        <i class="fa-brands fa-php"></i>
                        PHP
                    </div>
                    <div data-aos="fade-up-top" data-aos-duration="800">
                        <i class="fa-brands fa-laravel"></i>
                        laravel
                    </div>
                    <div data-aos="fade-up-top" data-aos-duration="800">
                        <i class="fa-brands fa-react"></i>
                        React
                    </div>
                </div>
            </div>


            <div class="portfolio" id="portfolio">
                <div class="title" data-aos="fade-right" data-aos-duration="800">
                    <i class="bi bi-pc-display-horizontal"></i> <?php echo e(trans('portfolio.portfolio')); ?>

                </div>
                <h1 data-aos="fade-right">
                    <?php echo e(trans('portfolio.work1')); ?><span><?php echo e(trans('portfolio.work2')); ?></span>
                </h1>
                <div class="jobs">
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div data-aos="fade-left" class="project">
                            <div>
                                <h3><?php echo e($project->project_name); ?></h3>
                                <div class="btn">
                                    <a href="<?php echo e($project->link); ?>" target="_blank">
                                        <button>
                                            Take a View
                                        </button>
                                    </a>

                                </div>
                            </div>

                            <img src="ProjectImages/<?php echo e($project->image); ?>" alt="">

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>







            <div class="contact" id="contact">
                <div class="title" data-aos="fade-right" data-aos-duration="800">
                    <i class="bi bi-envelope"></i><?php echo e(trans('portfolio.contact')); ?>

                </div>
                <div>
                    <h1 data-aos="fade-right">
                        <?php echo e(trans('portfolio.contact1')); ?> <span><?php echo e(trans('portfolio.contact2')); ?></span>
                    </h1>
                </div>

                <form data-aos="zoom-in-down" action="<?php echo e(route('message.store')); ?>" method="post" class="row up">
                    <?php echo csrf_field(); ?>
                    
                    <div class="col-md-6">
                        <label for=""> <?php echo e(trans('portfolio.fullname')); ?> :</label>
                        <input type="text" placeholder="your name" name="name">
                    </div>
                    <div class="col-md-6">
                        <label for=""> <?php echo e(trans('portfolio.subject')); ?> :</label>
                        <input type="text" placeholder="Subject" name="subject">
                    </div>
                    <div class="col-md-6">
                        <label for=""> <?php echo e(trans('portfolio.email')); ?> : </label>
                        <input type="text" placeholder="your email" name="email">
                    </div>
                    <div class="col-md-6">
                        <label for=""> <?php echo e(trans('portfolio.phone')); ?></label>
                        <input type="text" placeholder="your phone number" name="phone">
                    </div>
                    <div class="message col-12">
                        <label for=""> <?php echo e(trans('portfolio.message')); ?> : </label>
                        <textarea name="message" id="" cols="30" rows="8"></textarea>
                    </div>
                    <div class="btn col-12">
                        <BUtton> <?php echo e(trans('portfolio.send')); ?> </BUtton>
                    </div>


                </form>

            </div>
        </div>
    </div>





    <script src="scripts/script.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        $(document).ready(function() {
            $('.comment-icon').click(function() {
                $(this).siblings('.comment-area').toggle();
            });
        });

    </script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\laravel\portfolio2\resources\views/index.blade.php ENDPATH**/ ?>