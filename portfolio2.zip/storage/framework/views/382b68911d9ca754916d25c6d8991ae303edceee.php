<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('title'); ?>
        <?php echo e($startup->name); ?>

    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
   <h1> <?php echo e($startup->startup); ?>  Startup</h1>
    
        <table class="table table-striped-columns">
            <thead>
                <tr>
                    <th scope="col">Nom </th>
                    <td scope="col"><?php echo e($startup->fullname); ?></td>
                </tr>
                <tr>
                    <th scope="col">Email </th>
                    <td scope="col"><?php echo e($startup->email); ?></td>
                </tr>
                <tr>
                    <th scope="col">Numero Telephone </th>
                    <td scope="col"><?php echo e($startup->phone); ?></td>
                </tr>
                <tr>
                    <th scope="col">Startup </th>
                    <td scope="col"><?php echo e($startup->startup); ?></td>
                </tr>
                <tr>
                    <th scope="col">Wilaya </th>
                    <td scope="col"><?php echo e($startup->wilaya); ?></td>
                </tr>
                <tr>
                    <th scope="col">Description </th>
                    <td scope="col"><?php echo e($startup->desc); ?></td>
                </tr>
                <tr>
                    <th scope="col">Label </th>
                    <td scope="col"><?php echo e($startup->label); ?></td>
                </tr>
                <tr>
                    <th scope="col">Date de Creation </th>
                    <td scope="col"><?php echo e($startup->creation_date); ?></td>
                </tr>
                <tr>
                    <th scope="col">Site Web </th>
                    <td scope="col"><?php echo e($startup->website); ?></td>
                </tr>
                <tr>
                    <th scope="col">Date de Creation </th>
                    <td scope="col"><?php echo e($startup->creation_date); ?></td>
                </tr>
                <tr>
                    <th scope="col">Social Media </th>
                    <td scope="col"><?php echo e($startup->socialmedia); ?></td>
                </tr>
            </thead>
          
        </table>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\portfolio2\resources\views/admin/show.blade.php ENDPATH**/ ?>